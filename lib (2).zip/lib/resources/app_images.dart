class AppImages {
  static const profile = "assets/images/AppLogo.png";
  static const splash = "assets/images/splash.png";
  static const gender = "assets/images/Gender_image.png";
  static const age = "assets/images/AgeImage.PNG";
  static const weight = "assets/images/WeightImage.png";
  static const height = "assets/images/heightImage.png";
}
