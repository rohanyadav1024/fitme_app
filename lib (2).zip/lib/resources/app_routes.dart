class AppRoutes {
  static const genderPage = "/GenderPage";
  static const agePage = "/AgePage";
  static const weightPage = "/WeightPage";
  static const heightPage = "/HeightPage";

  static const bmr = "/BMR";
  static const bmi = "/BMI";
  static const bp = "/BP";
  static const waterintake = "/WaterIntake";
  static const bloodsugar = "/BloodSugar";
}

