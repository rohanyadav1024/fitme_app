class AppString {
  static const createProfile = "Create Profile";
  static const gender = "Which one are you ?";
  static const step = "STEP";
  static const weight = "What is your weight?";
  static const height = "WHAT'S YOUR HEIGHT?";
   static const age = "WHAT'S YOUR AGE ? ";
  static const skip = "Skip";
  static const description =
      "To give you a customize experience we need to know your gender";
}

