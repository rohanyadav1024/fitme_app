import 'package:get/get.dart';

class OnboardingController extends GetxController {
  var ismale = true.obs;
  var radioValue = 'Male'.obs;
}
