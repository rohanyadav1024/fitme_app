import 'package:get/get.dart';

class CalciController extends GetxController {
  var listofcalcis = [
    "bmrcalci",
    "bloodsugar",
    "bmi",
    "bpcalci",
    "watereintake"
  ];
}
