

double waterIntakeInLiters(double bodyWeightInPounds) {
  return bodyWeightInPounds * 0.5 / 33.814;
}

